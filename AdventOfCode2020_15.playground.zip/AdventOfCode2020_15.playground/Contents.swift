
var numbers = [[0, 3, 6], [1, 3, 2], [2, 1, 3], [1, 2, 3], [2, 3, 1], [3, 2, 1], [3, 1, 2]]
var theSpokenOnes: Set<Int> = []
var numberAge: [Int: Int] = [:]
var previous: Int = -1
var firstTimeSpoken = true

for nums in numbers {
    theSpokenOnes = []
    numberAge = [:]
    previous = -1
    firstTimeSpoken = true
    var startingNumbers = nums
    for turn in 1...2020 {
        //print("IT IS TURN \(turn)")
        if startingNumbers.isEmpty {
            
            if firstTimeSpoken {
                speak(0, turn: turn)
            } else {
                //speak the age
                //print("previous: \(previous)")
                //print("last turn for \(previous) was \(numberAge[previous])")
                let age = turn - numberAge[previous]! - 1
                numberAge[previous] = turn - 1
                //print("age: \(age)")
                speak(age, turn: turn)
            }
            
        } else {
            
            let spoken = startingNumbers.remove(at: 0)
            speak(spoken, turn: turn)
            
        }
        
    }
}
func speak(_ number: Int, turn: Int) {
    if turn == 2020 {
        print("Number: \(number)")
    }
    previous = number
    firstTimeSpoken = !theSpokenOnes.contains(number)
    //print(firstTimeSpoken)
    if firstTimeSpoken {
        theSpokenOnes.insert(number)
        numberAge[number] = turn
    }
}
